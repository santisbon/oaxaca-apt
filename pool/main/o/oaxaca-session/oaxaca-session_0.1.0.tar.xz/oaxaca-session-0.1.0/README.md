<!-- Generated from packages/session/README.md.in by scripts/render.py. Edit the .in file, not this one. -->
# oaxaca-session

The graphics and session metapackage: roadmap step 4. Installing `oaxaca-session` on top of `oaxaca-base` pulls in Mesa, Hyprland with Xwayland, uwsm, SDDM with Qt's Wayland plugin, the desktop portals, GNOME Keyring (the secret store desktop applications keep credentials in, with the PAM module that unlocks it with the login password), Quickshell 0.3.2 or newer (from our repository; the Qt/QML toolkit the desktop shell runs on), and `oaxaca-nvidia` for the NVIDIA install path. `scripts/rootfs-create.sh` installs this package when building the `session` profile of the root filesystem. See `docs/4 - session.md`.

Files this package installs besides its dependency list:

| Installed path | Purpose |
|---|---|
| `/etc/sddm.conf.d/10-oaxaca-wayland.conf` | SDDM's greeter runs on Wayland, under a Hyprland instance started with the file below |
| `/usr/share/oaxaca/sddm/hyprland.lua` | the Hyprland configuration for that greeter instance: no logo, no splash, no wallpaper, no animations |

No user, default session or login setting is configured here, and Oaxaca sets no autologin: a user logs in with a password. SDDM finds the session through `hyprland-uwsm.desktop`, which Ubuntu's `hyprland` package ships under `/usr/share/wayland-sessions/`; the installer (roadmap step 7) chooses the default session and the user.

<!-- Generated from packages/base/README.md.in by scripts/render.py. Edit the .in file, not this one. -->
# oaxaca-base

The base system metapackage: roadmap step 3. Installing `oaxaca-base` on a minbase root filesystem pulls in the kernel, boot chain, init, network, sound and the Oaxaca apt repository. `scripts/rootfs-create.sh` does exactly that to build the root filesystem tarball. See `docs/3 - rootfs.md`.

Files this package installs besides its dependency list:

| Installed path | Purpose |
|---|---|
| `/usr/lib/os-release` (base-files' copy diverted to `/usr/lib/os-release.ubuntu`) | the system identifies as Oaxaca: `ID=oaxaca`, `ID_LIKE="ubuntu debian"` |
| `/etc/apt/apt.conf.d/50oaxaca-no-recommends` | apt installs no Recommends |
| `/etc/netplan/01-oaxaca-network-manager.yaml` | netplan hands all interfaces to NetworkManager |

The snapd pin (`/etc/apt/preferences.d/oaxaca-no-snapd`) is written by `scripts/rootfs-create.sh`, not by this package: lintian's `package-installs-apt-preferences` error cites Debian policy, which keeps `/etc/apt/preferences.d/` for the local administrator.
